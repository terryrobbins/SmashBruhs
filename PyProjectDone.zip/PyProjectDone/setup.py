import cx_Freeze

executables = [cx_Freeze.Executable("main.py")]
include_files = ['Assets']





cx_Freeze.setup(
    name="Smash Bruh",
    options = {"build_exe":{"packages":["pygame"],
                            "include_files":include_files}},
    executables = executables

    )
