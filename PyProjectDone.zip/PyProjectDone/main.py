### Smashbros rip-off game ###
import pygame as pg
import random
import sys
from settings import *
from sprites import *
import time


class Game:
    def __init__(self):
        pg.init()
        pg.mixer.init()
        self.screen = pg.display.set_mode((screenWidth,screenHeight))
        pg.display.set_caption(TITLE)
        self.clock = pg.time.Clock()
        self.running = True

    def rock(self):
        global Snum
        global Snum2
        Snum = 1
        Snum2 = 1
        self.BGnum2 = 0
        self.kosfx = pg.mixer.Sound('assets/sounds/kosfx.mp3')
        pg.mixer.music.stop()
        pg.mixer.music.set_volume(.8)
        pg.mixer.music.load('assets/sounds/track1.mp3')
        pg.mixer.music.play(-1)
        self.all_sprites = pg.sprite.Group()
        self.platforms = pg.sprite.Group()
        self.players2 = pg.sprite.Group()
        self.players1 = pg.sprite.Group()

        self.player_1 = Player()
        self.all_sprites.add(self.player_1)
        self.players1.add(self.player_1)

        self.player_2 = Player2()
        self.all_sprites.add(self.player_2)
        self.players2.add(self.player_2)
        
        #creates platforms
        plat_1 = Platform(0, 0,92)
        plat_2 = Platform(1, 141,156)
        plat_3 = Platform(2, 446,156)
        #adds platforms to groups
        self.all_sprites.add(plat_1)
        self.platforms.add(plat_1)

        self.all_sprites.add(plat_2)
        self.platforms.add(plat_2)

        self.all_sprites.add(plat_3)
        self.platforms.add(plat_3)

        self.Currenthp = playerHp(0, 10, 240)
        self.all_sprites.add(self.Currenthp)
        self.Currenthp2 = playerHp(0, 500, 240)
        self.all_sprites.add(self.Currenthp2)

        self.scoreDash = Score(0,275,10)
        self.all_sprites.add(self.scoreDash)

        self.Currentscore = Score(1,225,10)
        self.all_sprites.add(self.Currentscore)
        self.Currentscore2 = Score(1,325,10)
        self.all_sprites.add(self.Currentscore2)
        

        self.mask = pg.mask.from_surface(plat_1.image)


        # runs run
        self.run()

    def space(self):
        global Snum
        global Snum2
        Snum = 1
        Snum2 = 1
        self.BGnum2 = 1
        self.kosfx = pg.mixer.Sound('assets/sounds/kosfx.mp3')
        pg.mixer.music.stop()
        pg.mixer.music.set_volume(.8)
        pg.mixer.music.load('assets/sounds/SpaceM.mp3')
        pg.mixer.music.play(-1)
        self.all_sprites = pg.sprite.Group()
        self.platforms = pg.sprite.Group()
        self.players2 = pg.sprite.Group()
        self.players1 = pg.sprite.Group()

        self.player_1 = Player()
        self.all_sprites.add(self.player_1)
        self.players1.add(self.player_1)

        self.player_2 = Player2()
        self.all_sprites.add(self.player_2)
        self.players2.add(self.player_2)
        
        #creates platforms
        plat_1 = Platform(3, 0,164)
        plat_2 = Platform(4, 138,185)
        plat_3 = Platform(5, 483,163)
        #adds platforms to groups
        self.all_sprites.add(plat_1)
        self.platforms.add(plat_1)

        self.all_sprites.add(plat_2)
        self.platforms.add(plat_2)

        self.all_sprites.add(plat_3)
        self.platforms.add(plat_3)

        self.Currenthp = playerHp(0, 10, 240)
        self.all_sprites.add(self.Currenthp)
        self.Currenthp2 = playerHp(0, 500, 240)
        self.all_sprites.add(self.Currenthp2)

        self.scoreDash = Score(0,275,10)
        self.all_sprites.add(self.scoreDash)

        self.Currentscore = Score(1,225,10)
        self.all_sprites.add(self.Currentscore)
        self.Currentscore2 = Score(1,325,10)
        self.all_sprites.add(self.Currentscore2)
        

        self.mask = pg.mask.from_surface(plat_1.image)


        # runs run
        self.run()

    def forest(self):
        global Snum
        global Snum2
        Snum = 1
        Snum2 = 1
        self.BGnum2 = 2
        self.kosfx = pg.mixer.Sound('assets/sounds/kosfx.mp3')
        pg.mixer.music.stop()
        pg.mixer.music.set_volume(.8)
        pg.mixer.music.load('assets/sounds/forestM.mp3')
        pg.mixer.music.play(-1)
        self.all_sprites = pg.sprite.Group()
        self.platforms = pg.sprite.Group()
        self.players2 = pg.sprite.Group()
        self.players1 = pg.sprite.Group()

        self.player_1 = Player()
        self.all_sprites.add(self.player_1)
        self.players1.add(self.player_1)

        self.player_2 = Player2()
        self.all_sprites.add(self.player_2)
        self.players2.add(self.player_2)
        
        #creates platforms
        plat_1 = Platform(6, 0,213)
        plat_2 = Platform(7, 184,194)
        plat_3 = Platform(8, 450,220)
        #adds platforms to groups
        self.all_sprites.add(plat_1)
        self.platforms.add(plat_1)

        self.all_sprites.add(plat_2)
        self.platforms.add(plat_2)

        self.all_sprites.add(plat_3)
        self.platforms.add(plat_3)

        self.Currenthp = playerHp(0, 10, 240)
        self.all_sprites.add(self.Currenthp)
        self.Currenthp2 = playerHp(0, 500, 240)
        self.all_sprites.add(self.Currenthp2)

        self.scoreDash = Score(0,275,10)
        self.all_sprites.add(self.scoreDash)

        self.Currentscore = Score(1,225,10)
        self.all_sprites.add(self.Currentscore)
        self.Currentscore2 = Score(1,325,10)
        self.all_sprites.add(self.Currentscore2)
        

        self.mask = pg.mask.from_surface(plat_1.image)


        # runs run
        self.run()

    def volcano(self):
        global Snum
        global Snum2
        Snum = 1
        Snum2 = 1
        self.BGnum2 = 3
        self.kosfx = pg.mixer.Sound('assets/sounds/kosfx.mp3')
        pg.mixer.music.stop()
        pg.mixer.music.set_volume(.8)
        pg.mixer.music.load('assets/sounds/volcanoM.mp3')
        pg.mixer.music.play(-1)
        self.all_sprites = pg.sprite.Group()
        self.platforms = pg.sprite.Group()
        self.players2 = pg.sprite.Group()
        self.players1 = pg.sprite.Group()

        self.player_1 = Player()
        self.all_sprites.add(self.player_1)
        self.players1.add(self.player_1)

        self.player_2 = Player2()
        self.all_sprites.add(self.player_2)
        self.players2.add(self.player_2)
        
        #creates platforms
        plat_1 = Platform(9, 5,169)
        plat_2 = Platform(10, 340,219)
        #adds platforms to groups
        self.all_sprites.add(plat_1)
        self.platforms.add(plat_1)

        self.all_sprites.add(plat_2)
        self.platforms.add(plat_2)


        self.Currenthp = playerHp(0, 10, 240)
        self.all_sprites.add(self.Currenthp)
        self.Currenthp2 = playerHp(0, 500, 240)
        self.all_sprites.add(self.Currenthp2)

        self.scoreDash = Score(0,275,10)
        self.all_sprites.add(self.scoreDash)

        self.Currentscore = Score(1,225,10)
        self.all_sprites.add(self.Currentscore)
        self.Currentscore2 = Score(1,325,10)
        self.all_sprites.add(self.Currentscore2)
        

        self.mask = pg.mask.from_surface(plat_1.image)


        # runs run
        self.run()




    def run(self):
        self.playing = True
        while self.playing:
            self.clock.tick(FPS)
            self.events()
            self.update()
            self.draw()

    def update(self):
        global Snum
        global Snum2
        
        if self.player_1.healthchange:
            self.player_1.Inum += 2
            self.all_sprites.remove(self.Currenthp)
            self.Currenthp = playerHp(self.player_1.Inum, 10, 240)
            self.all_sprites.add(self.Currenthp)
            self.player_1.healthchange = False

        if self.player_2.healthchange:
            self.player_2.Inum += 2
            self.all_sprites.remove(self.Currenthp2)
            self.Currenthp2 = playerHp(self.player_2.Inum, 500, 240)
            self.all_sprites.add(self.Currenthp2)
            self.player_2.healthchange = False

        if self.player_1.scorechange:
            Snum += 1
            self.all_sprites.remove(self.Currentscore)
            self.Currentscore = Score(Snum, 225,10)
            self.all_sprites.add(self.Currentscore)
            self.player_1.scorechange = False

        if self.player_2.scorechange:
            Snum2 += 1
            self.all_sprites.remove(self.Currentscore2)
            self.Currentscore2 = Score(Snum2, 325,10)
            self.all_sprites.add(self.Currentscore2)
            self.player_2.scorechange = False

        if Snum == -1:
            time.sleep(3)
            pg.mixer.music.load('assets/sounds/track3.mp3')
            pg.mixer.music.set_volume(.1)
            pg.mixer.music.play(-1)
            if self.playing:
                self.playing = False
            self.running = False
            g.MainMenu()
        if Snum2 == -1:
            time.sleep(3)
            pg.mixer.music.load('assets/sounds/track3.mp3')
            pg.mixer.music.set_volume(.1)
            pg.mixer.music.play(-1)
            if self.playing:
                self.playing = False
            self.running = False
            g.MainMenu()
        
        self.death()            

        
        self.all_sprites.update()
        hits = pg.sprite.spritecollide(self.player_1, self.platforms, False, pg.sprite.collide_mask)
        if hits:
            if self.player_1.pos.x < hits[0].rect.left:
                self.player_1.pos.x = hits[0].rect.left
                
            elif self.player_1.pos.x > hits[0].rect.right:
                self.player_1.pos.x = hits[0].rect.right
                
            elif self.player_1.pos.y < hits[0].rect.bottom:
                self.player_1.pos.y = hits[0].rect.top +3
                self.player_1.vel.y = 0

        hits = pg.sprite.spritecollide(self.player_2, self.platforms, False, pg.sprite.collide_mask)
        if hits:
            if self.player_2.pos.x < hits[0].rect.left:
                self.player_2.pos.x = hits[0].rect.left
                
            elif self.player_2.pos.x > hits[0].rect.right:
                self.player_2.pos.x = hits[0].rect.right
                
            elif self.player_2.pos.y < hits[0].rect.bottom:
                self.player_2.pos.y = hits[0].rect.top + 5
                self.player_2.vel.y = 0

        if self.player_1.punching and self.player_1.ptimer == 0:
            hits = pg.sprite.spritecollide(self.player_1, self.players2, False, pg.sprite.collide_mask)
            if hits:
                self.player_2.health += 10
                self.player_2.healthchange = True
                self.player_1.ptimer = 50
            self.player_1.punching = False
        elif self.player_1.punching:
            self.player_1.punching = False

        if self.player_1.kicking and self.player_1.ktimer == 0:
            hits = pg.sprite.spritecollide(self.player_1, self.players2, False, pg.sprite.collide_mask)
            if hits:
                self.player_2.health += 10
                self.player_2.healthchange = True
                self.player_1.ktimer = 50
            self.player_1.kicking = False
        elif self.player_1.kicking:
            self.player_1.kicking = False
                

        if self.player_2.punching and self.player_2.ptimer == 0:
            hits = pg.sprite.spritecollide(self.player_2, self.players1, False, pg.sprite.collide_mask)
            if hits:
                self.player_1.health += 10
                self.player_1.healthchange = True
                self.player_2.ptimer = 50
            self.player_2.punching = False
        elif self.player_2.punching:
            self.player_2.punching = False

        if self.player_2.kicking and self.player_2.ktimer == 0:
            hits = pg.sprite.spritecollide(self.player_2, self.players1, False, pg.sprite.collide_mask)
            if hits:
                self.player_1.health += 10
                self.player_1.healthchange = True
                self.player_2.ktimer = 50
            self.player_2.kicking = False
        elif self.player_2.kicking:
            self.player_2.kicking = False

        if self.player_1.ptimer > 0:
            self.player_1.ptimer -= 1
        if self.player_2.ptimer > 0:
            self.player_2.ptimer -= 1
        if self.player_1.ktimer > 0:
            self.player_1.ktimer -= 1
        if self.player_2.ktimer > 0:
            self.player_2.ktimer -= 1

    def events(self):
        for event in pg.event.get():
            mPos = pg.mouse.get_pos()
            if event.type == pg.QUIT:
                pg.quit()
                sys.exit()
            if event.type == pg.KEYDOWN:
                hits = pg.sprite.spritecollide(self.player_1,self.platforms,False)
                hits2 = pg.sprite.spritecollide(self.player_2,self.platforms,False)
                if event.key == pg.K_w and hits:
                    self.player_1.jump()
                if event.key == pg.K_UP and hits2:
                    self.player_2.jump()
                if event.key == pg.K_e:
                    self.player_1.punching = True
                if event.key == pg.K_r:
                    self.player_1.kicking = True
                if event.key == pg.K_RSHIFT:
                    self.player_2.punching = True
                if event.key == pg.K_RETURN:
                    self.player_2.kicking = True
                if event.key == pg.K_ESCAPE:
                    pg.mixer.music.load('assets/sounds/track3.mp3')
                    pg.mixer.music.set_volume(1.2)
                    pg.mixer.music.play(-1)
                    if self.playing:
                        self.playing = False
                    self.running = False

    def draw(self):
        self.screen.fill([255, 255, 255])
        BackGround = Background(self.BGnum2, [0,0])
        self.screen.blit(BackGround.image, BackGround.rect)
        self.all_sprites.draw(self.screen)
        pg.display.flip()

    def death(self):
        global Snum
        global Snum2
        
        if self.player_2.health == 100:
            self.player_2.deathsfx.play()
            self.all_sprites.remove(self.Currenthp2)
            self.Currenthp2 = playerHp(0, 500, 240)
            self.all_sprites.add(self.Currenthp2)
            self.player_2.pos.x = 545
            self.player_2.pos.y = -1000
            self.player_2.health = 0
            self.player_2.Inum = 0
            self.player_1.scorechange = True
        if self.player_1.health == 100:
            self.player_1.deathsfx.play()
            self.all_sprites.remove(self.Currenthp)
            self.Currenthp = playerHp(0, 5, 240)
            self.all_sprites.add(self.Currenthp)
            self.player_1.pos.x = 25
            self.player_1.pos.y = -1000
            self.player_1.health = 0
            self.player_1.Inum = 0
            self.player_2.scorechange = True

        if self.player_2.pos.y > 500:
            self.player_2.deathsfx.play()
            self.all_sprites.remove(self.Currenthp2)
            self.Currenthp2 = playerHp(0, 500, 240)
            self.all_sprites.add(self.Currenthp2)
            self.player_2.pos.x = 545
            self.player_2.pos.y = -1000
            self.player_2.Inum = 0
            self.player_1.scorechange = True
            
        if self.player_1.pos.y > 500:
            self.player_1.deathsfx.play()
            self.all_sprites.remove(self.Currenthp)
            self.Currenthp = playerHp(0, 5, 240)
            self.all_sprites.add(self.Currenthp)
            self.player_1.pos.x = 25
            self.player_1.pos.y = -1000
            self.player_1.Inum = 0
            self.player_2.scorechange = True
        if Snum == 4:
            self.all_sprites.remove(self.Currentscore)
            self.all_sprites.remove(self.Currentscore2)
            self.all_sprites.remove(self.scoreDash)
            self.kosfx.play()
            Snum = -1
            self.ko = Score(5,275,10)
            self.all_sprites.add(self.ko)
        if Snum2 == 4:
            self.all_sprites.remove(self.Currentscore)
            self.all_sprites.remove(self.Currentscore2)
            self.all_sprites.remove(self.scoreDash)
            self.kosfx.play()
            Snum2 = -1
            self.ko2 = Score(5,275,10)
            self.all_sprites.add(self.ko2)
        
            
            
        
        
            
            
    def MainMenu(self):
        click = False
        while True:
            self.screen.fill(BGCOLOR)
            self.screen.fill([255, 255, 255])
            MainMenu = Main_Menu('assets/sprites/menus/MainMenu.png', [0,0])
            self.screen.blit(MainMenu.image, MainMenu.rect)
            
            mx, my = pg.mouse.get_pos()

            sgButton = pg.Rect(329, 108, 225, 50)
            conButton = pg.Rect(298, 175, 264, 35)
            extButton = pg.Rect(424, 238, 130, 32)

            if sgButton.collidepoint((mx,my)):
                if click:
                    g.MapMenu()
            if conButton.collidepoint((mx,my)):
                if click:
                    g.controlMenu()
            if extButton.collidepoint((mx,my)):
                if click:
                    pg.quit()
                    sys.exit()

            pg.draw.rect(self.screen,(RED), sgButton,1)
            pg.draw.rect(self.screen,(RED), conButton,1)
            pg.draw.rect(self.screen,(RED), extButton,1)

            click = False
            for event in pg.event.get():
                if event.type == pg.QUIT:
                    pg.quit()
                    sys.exit()
                if event.type == pg.KEYDOWN:
                    if event.key == pg.K_ESCAPE:
                        pg.quit()
                        sys.exit()
                if event.type == pg.MOUSEBUTTONDOWN:
                    if event.button == 1:
                        click = True
                


            pg.display.update()
            self.clock.tick(FPS)

    def controlMenu(self):
        Cmenu = True
        while Cmenu:
            self.screen.fill([255, 255, 255])
            controlMenu1 = ControlMenu('assets/sprites/menus/controlMenu.png', [0,0])
            self.screen.blit(controlMenu1.image, controlMenu1.rect)
            pg.display.flip()
            for event in pg.event.get():
                if event.type == pg.QUIT:
                    pg.quit()
                    sys.exit()
                if event.type == pg.KEYDOWN:
                    if event.key == pg.K_ESCAPE:
                        Cmenu = False
    
    def MapMenu(self):
        Mmenu = True
        click = False
        while Mmenu:
            self.screen.fill([255, 255, 255])
            mapMenu1 = MapMenu('assets/sprites/menus/mapMenu.png', [0,0])
            self.screen.blit(mapMenu1.image, mapMenu1.rect)
            pg.display.flip()


            mx, my = pg.mouse.get_pos()

            rockButton = pg.Rect(5, 5, 133, 280)
            spaceButton = pg.Rect(140, 5, 145, 280)
            forestButton = pg.Rect(290, 5, 145, 280)
            volcanoButton = pg.Rect(440,5,133,280)

            if rockButton.collidepoint((mx,my)):
                if click:
                    g.rock()
            if spaceButton.collidepoint((mx,my)):
                if click:
                    g.space()
            if forestButton.collidepoint((mx,my)):
                if click:
                   g.forest()
            if volcanoButton.collidepoint((mx,my)):
                if click:
                    g.volcano()
                    

            pg.draw.rect(self.screen,(RED), rockButton,1)
            pg.draw.rect(self.screen,(RED), spaceButton,1)
            pg.draw.rect(self.screen,(RED), forestButton,1)
            pg.draw.rect(self.screen,(RED), volcanoButton,1)







            click = False
            for event in pg.event.get():
                if event.type == pg.QUIT:
                    pg.quit()
                    sys.exit()
                if event.type == pg.MOUSEBUTTONDOWN:
                    if event.button == 1:
                        click = True
                if event.type == pg.KEYDOWN:
                    if event.key == pg.K_ESCAPE:
                        Mmenu = False

            self.clock.tick(FPS)


g = Game()
pg.mixer.music.load('assets/sounds/track3.mp3')
pg.mixer.music.set_volume(1.2)
pg.mixer.music.play(-1)
g.MainMenu()
while g.running:
    g.new()
    g.show_go_screen()

g.MainMenu
